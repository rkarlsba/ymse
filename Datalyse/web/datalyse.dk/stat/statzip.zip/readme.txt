
zip-filen indeholder f�lgende filer:

	Stat.exe, selve programmet
	Stat.hlp, hj�lpefil
	readme.txt, denne fil
	*.txt, opgaver i normalfordelingen	

	Readme.txt, denne fil.


Installation:

Opret en mappe p� harddisken og udpak alle filer til denne mappe.

Opret en genvej i windows. Du kan ogs� bare klikke p� programmet Stat.exe i stifinden. 
Der er ingen indstillinger i windows. 
Det betyder ogs�, at programmet er nemt af afinstallere, man fjerner blot genvej og mappe.


Programmet Stat foruds�tter Windows 95, 98 eller nyere

I stat.ini kan man skrive adressen p� en arbejdsmappe til normalfordelingsopgaver, 
se vejledning i inifilen. Dette er praktisk, hvis programmet Stat l�ses fra et skrivebeskyttet
drev p� en server.


1/1 2008
Carl Hemmingsen

