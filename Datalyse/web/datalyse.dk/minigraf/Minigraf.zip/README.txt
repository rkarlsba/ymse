Readme.txt
Minigraf.zip indeholder f�lgende filer:


readme.txt	Denne fil

Minigraf.exe    Programmet minigraf til Windows 95 og nyere versioner
Wgraf.hlp	Hj�lpefil lavet til en tidligere version af Minigraf.
		Denne hj�lpefil kan benyttes som dokumentation.


*.mgr    	opgaver til Minigraf


Installation:
-------------------------------------------------------------------

Der h�rer ingen systemfiler til Minigraf. Du skal blot oprette en genvej
eller benytte stifinderen og klikke p� Minigraf.exe


1/1 2008
Carl Hemmingsen

