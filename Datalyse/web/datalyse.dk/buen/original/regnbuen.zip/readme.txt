Regnbuen readme.txt
	Det er denne fil.

P� disketten ligger f�lgende filer:
Regnbuen.exe
	Selve programmet til Windows

De f�lgende filer er ikke n�dvendige, men anbefales.


Regnbuen.ini
	Filen indeholder valg af separatortegn, som benyttes i tabellen.
	Udelades inifilen benyttes windows separatortegn, men det er ikke altid lige heldigt, n�r data skal inds�ttes fx i excel.

Regnbuen.jpg
	Billede af regnbuerne 

Regnbuen.rtf
	Denne fil indl�ses og vises i regnbuens Memo. Filen indeholder hj�lp og �velser. Filen kan redigeres i et tekstbehandlingsprogram, men husk, at gemme i rtf-format.


Installation:
	Opret et katalog p� harddisken og kopier alle filer til dette katalog. Opret en genvej i Windows. Du kan ogs� bare klikke p� programmet i stifinden. Der er ingen indstillinger i windows. Det betyder ogs�, at programmet er nemt af afinstallere, man fjerner blot genvej og katalog.

Frederikssund, december 2010.

Med venlig hilsen
Carl Hemmingsen
