Installation af Organavn32.

Kopier programfilen <Organavn.exe> og helpfilen <Orgahlp.hlp> over i 
samme katalog og opret en genvej til <Organavn.exe>.

I Organavn version 4.1 benyttes IUPAC-navngivning svarende til Kemisk Ordbog,1996. D.v.s. navne som propan-2-ol og pentan-3-on.
Programmet accepterer ikke de gamle navne (vil man bruge dem, m� man anvende ORGANAVN Ver 4,0.

N�r programmet k�rer, kan man bruge Hj�lp|Om Programmet til at f� en 
kort oversigt over, hvordan programmet fungerer - hvis det skulle v�re 
n�dvendigt.
Man kan ogs� bruge Hj�lp|Om navngivningen til at f� oplysning om, 
hvordan programmet navngiver.

Er der programproblemer, kontakt Carl Hemmingsen eller mig.
Er der kommentarer mht. programmets m�de at arbejde p�, til 
navngivningen eller lignende, kontakt mig.

Jeg kan tr�ffes p� tlf.nr. 38 11 46 25, men foretr�kker en mail
til NILS.MUNTHER@SKOLEKOM.DK

Mvh. Nils M�nther