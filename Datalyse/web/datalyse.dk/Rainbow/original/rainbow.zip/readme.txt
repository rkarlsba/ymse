The Rain readme.txt
	This file.

On the disc the following files can be found:
Rainbow.exe
	The main program which requires Windows.

The following files are not necessary but recommended.


Rainbow.ini
	The file contains the choice of separator character for the table.
	Without this file, the Windows separator characters are used which isn't always such a good idea.

Rainbow.bmp
	Picture of the rainbows.

Rainbow.rtf
	This file is displayed in The Rainbow's Memo. The file contains help and exercises. The file may be edited in a word processor, but remember to save it in rtf format.


Installation:
	Create a directory on the hard drive and copy all files to this directory. Create a link in Windows. Or simply click the program in the Explorer. No files need to be moved to the Windows directory. This makes the program easy to uninstall; simply remove the link and the directory.

Fredeeriksund, December 2010.

Best regards
Carl Hemmingsen
